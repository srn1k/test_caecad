% Общие параметры
l = 1;              % Длина струны
a = 1;              % Скорость волны
omega = 5;          % Частота внешней силы
N_terms = 20;       % Количество членов ряда Фурье (для аналитического решения)
N = 100;            % Количество точек по пространству (для численного решения)
M = 1000;           % Количество точек по времени
h = l / N;          % Шаг по пространству
tau = 0.001;        % Шаг по времени

% Проверка условия Куранта
if (a * tau / h > 1)
    error('Условие Куранта не выполнено! Уменьшите шаг по времени.');
end

% Инициализация сеток
x = linspace(0, l, N+1);
t = linspace(0, tau*M, M+1);
[X_num, T_num] = meshgrid(x, t);
U_num = zeros(N+1, M+1);  % Численное решение
U_anal = zeros(size(X_num)); % Аналитическое решение

% Функции начальных условий и внешней силы (пример)
phi0 = @(x) sin(pi * x / l);    % Начальное отклонение
phi1 = @(x) 0;                  % Начальная скорость
f = @(x) sin(pi * x / l);       % Пространственная часть силы

% =============================================
% Численное решение (метод конечных разностей)
% =============================================

% Заполнение начальных условий
for i = 1:N+1
    U_num(i, 1) = phi0(x(i));
    U_num(i, 2) = phi0(x(i)) + tau * phi1(x(i));
end

% Матрица для метода прогонки
alpha = zeros(N-1, 1);
beta = zeros(N-1, 1);
A_coeff = -a^2 * tau^2 / h^2;
B_coeff = 1 + 2 * a^2 * tau^2 / h^2;

% Цикл по времени
for k = 2:M
    % Правая часть уравнения
    F = arrayfun(f, x(2:N))' * sin(omega * t(k));
    rhs = 2 * U_num(2:N, k) - U_num(2:N, k-1) + tau^2 * F;

    % Метод прогонки (Thomas algorithm)
    alpha(1) = -A_coeff / B_coeff;
    beta(1) = rhs(1) / B_coeff;
    for i = 2:N-1
        denom = B_coeff + A_coeff * alpha(i-1);
        alpha(i) = -A_coeff / denom;
        beta(i) = (rhs(i) - A_coeff * beta(i-1)) / denom;
    end

    U_num(N, k+1) = beta(N-1);
    for i = N-1:-1:2
        U_num(i, k+1) = alpha(i-1) * U_num(i+1, k+1) + beta(i-1);
    end
end

% =============================================
% Аналитическое решение
% =============================================

% Проверка на резонанс
resonance = false;
n_resonance = 0;
for n = 1:N_terms
    if abs(omega - a * n * pi / l) < 1e-6
        resonance = true;
        n_resonance = n;
        break;
    end
end

% Вычисление коэффициентов a_n, b_n, f_n
a_n = zeros(1, N_terms);
b_n = zeros(1, N_terms);
f_n = zeros(1, N_terms);
for n = 1:N_terms
    integrand_a = @(x) phi0(x) .* sin(n * pi * x / l);
    integrand_b = @(x) phi1(x) .* sin(n * pi * x / l);
    integrand_f = @(x) f(x) .* sin(n * pi * x / l);

    a_n(n) = (2 / l) * integral(integrand_a, 0, l);
    b_n(n) = (2 / (n * pi * a)) * integral(integrand_b, 0, l);
    f_n(n) = (2 / l) * integral(integrand_f, 0, l);
end

% Построение аналитического решения
for n = 1:N_terms
    omega_n = a * n * pi / l;
    if resonance && n == n_resonance
        % Резонансный член
        U_anal = U_anal + (f_n(n) / (2 * omega_n^2)) * ...
            (sin(omega_n * T_num) - T_num * omega_n .* cos(omega_n * T_num)) .* ...
            sin(n * pi * X_num / l);
    else
        % Обычный член
        U_anal = U_anal + (a_n(n) * cos(omega_n * T_num) + b_n(n) * sin(omega_n * T_num)) .* ...
            sin(n * pi * X_num / l);
        if abs(omega_n^2 - omega^2) > 1e-6
            U_anal = U_anal + (f_n(n) / (omega_n^2 - omega^2)) * ...
                (omega * sin(omega_n * T_num) - omega_n * sin(omega * T_num)) .* ...
                sin(n * pi * X_num / l);
        end
    end
end


% =============================================
% Визуализация результатов
% =============================================

% График аналитического решения
figure(1);
surf(X_num, T_num, U_anal);
xlabel('x');
ylabel('t');
zlabel('u(x,t)');
title('Аналитическое решение');

% График численного решения
figure(2);
surf(X_num, T_num, U_num');
xlabel('x');
ylabel('t');
zlabel('u(x,t)');
title('Численное решение');

% Интерполяция численного решения на сетку аналитического
U_num_interp = zeros(size(X_num));
for i = 1:length(t)
    U_num_interp(i,:) = interp1(x, U_num(:,i), X_num(i,:), 'spline');
end

% Абсолютная погрешность
abs_error = abs(U_anal - U_num_interp);

% График абсолютной погрешности
figure(3);
surf(X_num, T_num, abs_error);
xlabel('x');
ylabel('t');
zlabel('Absolute error');
title('Абсолютная погрешность');

% Вычисление L₂-нормы невязки
L2_norm = zeros(1, length(t));
for k = 1:length(t)
    diff = U_anal(k,:) - U_num_interp(k,:);
    L2_norm(k) = sqrt(sum(diff.^2) / length(x));
end

% График L₂-нормы невязки в зависимости от времени
figure(4);
plot(t, L2_norm, 'LineWidth', 2);
xlabel('Время (t)');
ylabel('L₂-норма невязки');
title('Зависимость L₂-нормы невязки от времени');
grid on;

% Графики решений в один момент времени для сравнения
t_compare = 0.5; % Момент времени для сравнения
[~, t_idx] = min(abs(t - t_compare));

figure(5);
plot(x, U_num(:, t_idx), 'b-', 'LineWidth', 2, 'DisplayName', 'Численное');
hold on;
plot(X_num(1,:), U_anal(t_idx, :), 'r--', 'LineWidth', 2, 'DisplayName', 'Аналитическое');
xlabel('x');
ylabel('u(x,t)');
title(['Сравнение решений в момент t = ', num2str(t_compare)]);
legend();
grid on;
hold off;

% Вывод максимальной абсолютной погрешности и L₂-нормы
max_abs_error = max(abs_error(:));
max_L2_norm = max(L2_norm);
disp(['Максимальная абсолютная погрешность: ', num2str(max_abs_error)]);
disp(['Максимальная L₂-норма невязки: ', num2str(max_L2_norm)]);
