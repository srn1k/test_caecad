% Параметры задачи
l = 1;          % Длина струны
a = 1;          % Скорость волны
T = 2;          % Время моделирования

% Начальные условия и функция силы
phi0 = @(x) 0.1 * sin(pi*x/l);
phi1 = @(x) 0;
f = @(x) sin(pi*x/l);

% Параметры дискретизации
Nx = 100;       % Число точек по пространству
Nt = 500;       % Число точек по времени
N_terms = 20;   % Число членов в рядах Фурье

% Частота внешней силы (обычный случай)
omega = 5*pi;

% 1. Аналитическое решение
function u = analytical_solution(x, t, l, a, omega, phi0, phi1, f, N_terms)
    u = zeros(length(x), length(t));

    for n = 1:N_terms
        wn = a * n * pi / l;

        % Численное интегрирование для коэффициентов
        integrand_a = @(xi) phi0(xi) .* sin(n*pi*xi/l);
        a_n = 2/l * integral(integrand_a, 0, l);

        integrand_b = @(xi) phi1(xi) .* sin(n*pi*xi/l);
        b_n = 2/(n*pi*a) * integral(integrand_b, 0, l);

        integrand_f = @(xi) f(xi) .* sin(n*pi*xi/l);
        f_n = 2/l * integral(integrand_f, 0, l);

        X_n = sin(n*pi*x(:)/l);

        for k = 1:length(t)
            if abs(wn^2 - omega^2) > 1e-6  % Не резонансный случай
                term1 = a_n * cos(wn*t(k)) + b_n * sin(wn*t(k));
                term2 = f_n/(wn^2 - omega^2) * (omega*sin(wn*t(k)) - wn*sin(omega*t(k)));
                u(:,k) = u(:,k) + (term1 + term2) * X_n;
            else  % Резонансный случай
                term1 = a_n * cos(wn*t(k)) + b_n * sin(wn*t(k));
                term2 = f_n/(2*wn) * (sin(wn*t(k))/wn - t(k)*cos(wn*t(k)));
                u(:,k) = u(:,k) + (term1 + term2) * X_n;
            end
        end
    end
end

% 2. Численное решение методом конечных разностей
function [u_num, x, t] = numerical_solution(l, T, a, omega, phi0, phi1, f, Nx, Nt)
    h = l / (Nx - 1);
    tau = T / (Nt - 1);

    % Проверка устойчивости (CFL условие)
    if a * tau / h > 1
        error('Схема неустойчива! Уменьшите шаг по времени или увеличьте шаг по пространству.');
    end

    x = linspace(0, l, Nx)';
    t = linspace(0, T, Nt);

    u_num = zeros(Nx, Nt);

    % Начальные условия
    u_num(:,1) = phi0(x);

    % Первый шаг по времени
    u_num(:,2) = u_num(:,1) + tau * phi1(x) + 0.5 * (a*tau/h)^2 * ...
        ([u_num(2:end,1); 0] - 2*u_num(:,1) + [0; u_num(1:end-1,1)]) + ...
        0.5 * tau^2 * f(x) * sin(omega*t(1));

    % Последующие шаги
    for j = 2:Nt-1
        % Внутренние точки
        for i = 2:Nx-1
            u_num(i,j+1) = 2*u_num(i,j) - u_num(i,j-1) + ...
                (a*tau/h)^2 * (u_num(i+1,j) - 2*u_num(i,j) + u_num(i-1,j)) + ...
                tau^2 * f(x(i)) * sin(omega*t(j));
        end

        % Граничные условия
        u_num(1,j+1) = 0;
        u_num(end,j+1) = 0;
    end
end

% 3. Решение и визуализация для обычного случая
[u_num, x, t] = numerical_solution(l, T, a, omega, phi0, phi1, f, Nx, Nt);
u_anal = analytical_solution(x, t, l, a, omega, phi0, phi1, f, N_terms);

% Графики для обычного случая
figure;
subplot(2,2,1);
surf(t, x, u_num);
title('Численное решение');
xlabel('Время'); ylabel('Позиция'); zlabel('Отклонение');

subplot(2,2,2);
surf(t, x, u_anal);
title('Аналитическое решение');
xlabel('Время'); ylabel('Позиция'); zlabel('Отклонение');

error = abs(u_num - u_anal);
subplot(2,2,3);
surf(t, x, error);
title('Абсолютная погрешность');
xlabel('Время'); ylabel('Позиция'); zlabel('Погрешность');

t_idx = round(Nt/2);
subplot(2,2,4);
plot(x, u_num(:,t_idx), x, u_anal(:,t_idx), '--');
title(['Срез при t = ' num2str(t(t_idx))]);
xlabel('Позиция'); ylabel('Отклонение');
legend('Численное', 'Аналитическое');

% 4. Анализ резонансного случая
n_resonance = 1;                % Номер резонансной моды
omega_res = a * n_resonance * pi / l;  % Резонансная частота

% Решения для резонансного случая
u_res_anal = analytical_solution(x, t, l, a, omega_res, phi0, phi1, f, N_terms);
[u_res_num, x, t] = numerical_solution(l, T, a, omega_res, phi0, phi1, f, Nx, Nt);

% Графики для резонансного случая
figure;
subplot(1,2,1);
surf(t, x, u_res_num);
title('Численное решение (резонанс)');
xlabel('Время'); ylabel('Позиция'); zlabel('Отклонение');

subplot(1,2,2);
plot(t, u_res_num(round(Nx/2),:));
title('Колебания в центре струны (резонанс)');
xlabel('Время'); ylabel('Отклонение');

% 5. Сравнение амплитуд в резонансе и без
figure;
plot(t, u_num(round(Nx/2),:), 'b', t, u_res_num(round(Nx/2),:), 'r');
title('Сравнение колебаний в центре струны');
xlabel('Время'); ylabel('Отклонение');
legend('Обычный случай', 'Резонанс');
