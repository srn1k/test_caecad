% Параметры
l = 1; a = 1; omega = 2*pi; N = 100; M = 500; T = 1;
dx = l/N; dt = T/M; r = (a*dt/dx)^2;

% Инициализация
x = linspace(0,l,N+1); t = linspace(0,T,M+1);
u = zeros(N+1,M+1);
phi0 = sin(pi*x/l); phi1 = zeros(1,N+1); f = sin(pi*x/l);
u(:,1) = phi0;

% Первый шаг
u(2:N,2) = u(2:N,1) + dt*phi1(2:N) + 0.5*r*(u(3:N+1,1)-2*u(2:N,1)+u(1:N-1,1));

% Явная схема
for k = 2:M
    u(2:N,k+1) = 2*u(2:N,k) - u(2:N,k-1) + r*(u(3:N+1,k)-2*u(2:N,k)+u(1:N-1,k)) + dt^2*f(2:N)'*sin(omega*t(k));
end

% Визуализация
[X,T] = meshgrid(x,t);
surf(X,T,u');
xlabel('x'); ylabel('t'); zlabel('u(x,t)');
title(sprintf('Колебания струны (ω=%.2f)',omega));

% Метод прогонки (запасной вариант)
function x = thomas(a,b,c,d)
    n = length(b); cp = zeros(n-1,1); dp = zeros(n,1);
    cp(1) = c(1)/b(1); dp(1) = d(1)/b(1);
    for i = 2:n-1
        denom = b(i)-a(i)*cp(i-1);
        cp(i) = c(i)/denom;
        dp(i) = (d(i)-a(i)*dp(i-1))/denom;
    end
    x = zeros(n,1);
    x(n) = (d(n)-a(n)*dp(n-1))/(b(n)-a(n)*cp(n-1));
    for i = n-1:-1:1
        x(i) = dp(i)-cp(i)*x(i+1);
    end
end
