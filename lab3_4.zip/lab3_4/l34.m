clear; clc;

% Параметры
L = 1;
a = 1;
Nx = 50;
Nt = 500;
dx = L / (Nx - 1);
dt = 0.001;
x = linspace(0, L, Nx);
t = linspace(0, 5, Nt);

% Начальные условия
phi0 = sin(pi * x);
phi1 = zeros(1, Nx);

% Внешняя сила f(x) = sin(pi*x)
f_x = sin(pi * x);

% Частоты
omega_cases = [pi/2, pi, 2*pi];

figure;
for test_id = 1:length(omega_cases)
    omega = omega_cases(test_id);
    r = (a * dt / dx)^2;

    % Матрица A для метода прогонки
    A = diag((1 + 2*r) * ones(1, Nx)) + diag(-r * ones(1, Nx-1), 1) + diag(-r * ones(1, Nx-1), -1);
    A(1, :) = 0; A(end, :) = 0;
    A(1,1) = 1; A(end, end) = 1; % Граничные условия

    % Решение
    u = zeros(Nx, Nt);
    u(:, 1) = phi0;
    u(:, 2) = phi0 + dt * phi1;

    % Метод прогонки
    alpha = zeros(Nx, 1);
    beta = zeros(Nx, 1);

    for n = 2:Nt-1
        F = f_x' * sin(omega * t(n));
        b = 2*u(:, n) - u(:, n-1) + (dt^2) * F;
        b(1) = 0; b(end) = 0; % Граничные условия

        % Прямой ход прогонки
        alpha(2) = A(2,3) / A(2,2);
        beta(2) = b(2) / A(2,2);
        for i = 3:Nx-1
            denom = A(i,i) - A(i,i-1) * alpha(i-1);
            alpha(i) = A(i,i+1) / denom;
            beta(i) = (b(i) - A(i,i-1) * beta(i-1)) / denom;
        end

        % Обратный ход прогонки
        u(Nx,n+1) = 0;
        for i = Nx-1:-1:2
            u(i,n+1) = beta(i) - alpha(i) * u(i+1,n+1);
        end
    end

    % Аналитическое решение
    u_analytical = zeros(Nx, Nt);
    for n = 1:Nt
        for m = 1:10  % Ограничиваем сумму 10 членами
            omega_m = m * pi * a / L;
            f_m = (2 / L) * trapz(x, f_x .* sin(m * pi * x / L));
            u_analytical(:, n) = u_analytical(:, n) + ...
                (f_m / (omega^2 - omega_m^2)) * ...
                (omega * sin(omega_m * t(n)) - omega_m * sin(omega * t(n))) * sin(m * pi * x / L);
        end
    end

    % Графики
    subplot(3, 2, 2 * test_id - 1);
    imagesc(t, x, u);
    xlabel('Время'); ylabel('x');
    title(['Численное решение, \omega = ', num2str(omega)]);
    colorbar;

    subplot(3, 2, 2 * test_id);
    imagesc(t, x, u_analytical);
    xlabel('Время'); ylabel('x');
    title(['Аналитическое решение, \omega = ', num2str(omega)]);
    colorbar;
end

