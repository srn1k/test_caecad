aaa = 1;

function value = u(x, t, params)
    value = x .* (params.l - x) .* sin(params.omega * t);
end

function value = phi0(x, params)
    value = 0;
end

function value = phi1(x, params)
    value = params.omega * x .* (params.l - x);
end

function value = f(x, params)
    value = -params.omega^2 * x .* (params.l - x) - 2 * params.a^2;
end

function u = thomas(a, b, c, f)
    N = length(f);
    alpha = zeros(N, 1);
    beta = zeros(N, 1);
    u = zeros(N, 1);

    % Прямой ход
    alpha(1) = c(1) / b(1);
    beta(1) = f(1) / b(1);

    for i = 2:N-1
        denom = b(i) - a(i-1) * alpha(i-1);
        alpha(i) = c(i) / denom;
        beta(i) = (f(i) - a(i-1) * beta(i-1)) / denom;
    end

    beta(N) = (f(N) - a(N-1) * beta(N-1)) / (b(N) - a(N-1) * alpha(N-1));

    % Обратный ход
    u(N) = beta(N);
    for i = N-1:-1:1
        u(i) = beta(i) - alpha(i) * u(i+1);
    end
end

function [x_grid, t_grid, u_grid] = solve(n, params)
    % Создание сеток по x и t
    u_grid = zeros(n, n);
    x_grid = linspace(0, params.l, n);
    t_grid = linspace(0, params.T, n);

    % Шаги по x и t
    x_step = x_grid(2) - x_grid(1);
    t_step = t_grid(2) - t_grid(1);

    sigma = params.a * t_step / x_step;

    % Начальные условия
    u_grid(1, :) = phi0(x_grid, params);
    u_grid(2, :) = u_grid(1, :) + t_step * phi1(x_grid, params);

    for i = 3:n
        % Коэффициенты для метода прогонки
        ld = -sigma^2;
        md = 1 + 2 * sigma^2;
        ud = -sigma^2;

        lower = ld * ones(n-1, 1);
        main  = md * ones(n, 1);
        upper = ud * ones(n-1, 1);

        main(1) = 1;
        upper(1) = 0;
        main(n) = 1;
        lower(n-1) = 0;

        % Правая часть уравнения
        rhs = 2 * u_grid(i-1, :) - u_grid(i-2, :) + t_step^2 * f(x_grid, params) * sin(params.omega * i * t_step);
        rhs(1) = 0;
        rhs(n) = 0;

        % Решение системы методом прогонки
        u_grid(i, :) = thomas(lower, main, upper, rhs);
    end
end

params.a = 1;
params.omega = 6;
params.l = 2 * pi;
params.T = 0.1;

n = 100;

[x, t, u_numeric] = solve(n, params);

u_analytic = zeros(n, n);
for i = 1:n
    for j = 1:n
        u_analytic(i, j) = u(x(j),  t(i), params);
    end
end

disp(max(max(abs(u_numeric - u_analytic))));

figure;
surfc(x, t, u_numeric);
surfc(x, t, u_analytic);

