% Параметры задачи
l = 1;              % Длина струны
a = 1;              % Скорость распространения волны
omega = 5;          % Частота внешней силы
N_terms = 20;       % Количество членов ряда Фурье для аналитического решения
N = 100;            % Число точек по пространству
M = 1000;           % Число точек по времени
h = l/N;            % Шаг по пространству
tau = 0.001;        % Шаг по времени

% Проверка условия Куранта
if (a*tau/h > 1)
    error('Нарушено условие Куранта. Уменьшите шаг по времени.');
end

% Инициализация сеток
x = linspace(0, l, N+1);
t = linspace(0, tau*M, M+1);
[X_num, T_num] = meshgrid(x, t);

% Функции начальных условий и внешней силы
phi0 = @(x) sin(pi*x/l);     % Начальное отклонение
phi1 = @(x) 0;               % Начальная скорость
f = @(x) sin(pi*x/l);        % Пространственное распределение силы

%% Численное решение (метод конечных разностей)
U_num = zeros(N+1, M+1);

% Начальные условия
for i = 1:N+1
    U_num(i,1) = phi0(x(i));
    U_num(i,2) = phi0(x(i)) + tau*phi1(x(i));
end

% Коэффициенты для метода прогонки
alpha = zeros(N-1,1);
beta = zeros(N-1,1);
A = -a^2*tau^2/h^2;
B = 1 + 2*a^2*tau^2/h^2;

% Цикл по времени
for k = 2:M
    % Правая часть уравнения
    F = arrayfun(f, x(2:N))' * sin(omega*t(k));
    rhs = 2*U_num(2:N,k) - U_num(2:N,k-1) + tau^2*F;

    % Метод прогонки (Thomas algorithm)
    alpha(1) = -A/B;
    beta(1) = rhs(1)/B;
    for i = 2:N-1
        denom = B + A*alpha(i-1);
        alpha(i) = -A/denom;
        beta(i) = (rhs(i) - A*beta(i-1))/denom;
    end

    U_num(N,k+1) = beta(N-1);
    for i = N-1:-1:2
        U_num(i,k+1) = alpha(i-1)*U_num(i+1,k+1) + beta(i-1);
    end
end

%% Аналитическое решение
% Проверка на резонанс
resonance = false;
n_resonance = 0;
for n = 1:N_terms
    if abs(omega - a*n*pi/l) < 1e-6
        resonance = true;
        n_resonance = n;
        break;
    end
end

% Вычисление коэффициентов Фурье
a_n = zeros(1,N_terms);
b_n = zeros(1,N_terms);
f_n = zeros(1,N_terms);
for n = 1:N_terms
    integrand_a = @(x) phi0(x).*sin(n*pi*x/l);
    integrand_b = @(x) phi1(x).*sin(n*pi*x/l);
    integrand_f = @(x) f(x).*sin(n*pi*x/l);

    a_n(n) = (2/l)*integral(integrand_a, 0, l);
    b_n(n) = (2/(n*pi*a))*integral(integrand_b, 0, l);
    f_n(n) = (2/l)*integral(integrand_f, 0, l);
end

% Построение аналитического решения
U_anal = zeros(size(X_num));
for n = 1:N_terms
    omega_n = a*n*pi/l;
    if resonance && n == n_resonance
        % Резонансный случай
        U_anal = U_anal + (f_n(n)/(2*omega_n^2)) * ...
            (sin(omega_n*T_num) - T_num.*omega_n.*cos(omega_n*T_num)) .* ...
            sin(n*pi*X_num/l);
    else
        % Общий случай
        U_anal = U_anal + (a_n(n)*cos(omega_n*T_num) + b_n(n)*sin(omega_n*T_num)) .* ...
            sin(n*pi*X_num/l);
        if abs(omega_n^2 - omega^2) > 1e-6
            U_anal = U_anal + (f_n(n)/(omega_n^2 - omega^2)) * ...
                (omega*sin(omega_n*T_num) - omega_n*sin(omega*T_num)) .* ...
                sin(n*pi*X_num/l);
        end
    end
end

%% Визуализация результатов

% 1. Графики решений в 3D
figure(1);
subplot(1,2,1);
surf(X_num, T_num, U_anal);
xlabel('x'); ylabel('t'); zlabel('u(x,t)');
title('Аналитическое решение');
shading interp;

subplot(1,2,2);
surf(X_num, T_num, U_num');
xlabel('x'); ylabel('t'); zlabel('u(x,t)');
title('Численное решение');
shading interp;

% 2. Сравнение решений в момент времени t = 0.5
t_compare = 0.5;
[~, t_idx] = min(abs(t - t_compare));

% Интерполяция численного решения для сравнения
U_num_interp = interp1(x, U_num(:,t_idx), X_num(1,:), 'spline');

figure(2);
plot(X_num(1,:), U_anal(t_idx,:), 'r-', 'LineWidth', 2, 'DisplayName', 'Аналитическое');
hold on;
plot(X_num(1,:), U_num_interp, 'b--', 'LineWidth', 2, 'DisplayName', 'Численное');
xlabel('x'); ylabel('u(x,t)');
title(['Сравнение решений при t = ', num2str(t_compare)]);
legend(); grid on;
hold off;

% 3. Расчет и визуализация погрешностей
abs_error = abs(U_anal - U_num');
max_abs_error = max(abs_error(:));

% L2 норма невязки по времени
L2_norm = zeros(1,length(t));
for k = 1:length(t)
    diff = U_anal(k,:) - interp1(x, U_num(:,k), X_num(1,:), 'spline');
    L2_norm(k) = sqrt(sum(diff.^2)/length(x));
end

figure(3);
plot(t, L2_norm, 'LineWidth', 2);
xlabel('Время'); ylabel('L_2 норма невязки');
title('Зависимость L_2 нормы невязки от времени');
grid on;

% Вывод максимальных погрешностей
disp(['Максимальная абсолютная погрешность: ', num2str(max_abs_error)]);
disp(['Максимальная L2 норма невязки: ', num2str(max(L2_norm))]);

%% Дополнительная проверка данных
disp('Проверка крайних значений:');
disp(['Аналитическое (min/max): ', num2str(min(U_anal(:))), ' / ', num2str(max(U_anal(:)))]);
disp(['Численное (min/max): ', num2str(min(U_num(:))), ' / ', num2str(max(U_num(:)))]);
