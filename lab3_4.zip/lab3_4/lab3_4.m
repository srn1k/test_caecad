clear; clc;

L = 1;       % Длина струны
a = 1;       % Скорость распространения
Nx = 50;     % Количество узлов по x
Nt = 500;    % Количество временных шагов
dx = L / (Nx - 1);
dt = 0.001;  % Шаг по времени
x = linspace(0, L, Nx);
t = linspace(0, 5, Nt);

% Начальные условия
phi0 = sin(pi * x);   % u(x,0)
phi1 = zeros(1, Nx);  % du/dt(x,0)

% Внешняя сила f(x) = sin(pi*x)
f_x = sin(pi * x);

omega_cases = [pi/2, pi, 2*pi]; % Три теста

figure;
for test_id = 1:length(omega_cases)
    omega = omega_cases(test_id);

    % Матрица трехдиагональной прогонки
    r = (a * dt / dx)^2;
    A = diag((1 + 2*r) * ones(1, Nx)) + diag(-r * ones(1, Nx-1), 1) + diag(-r * ones(1, Nx-1), -1);
    A(1, :) = 0; A(end, :) = 0; % Граничные условия

    % Численное решение
    u = zeros(Nx, Nt);
    u(:, 1) = phi0;
    u(:, 2) = phi0 + dt * phi1;

    for n = 2:Nt-1
        F = f_x * sin(omega * t(n));
        b = 2 * u(:, n) - u(:, n-1) + (dt^2) * F(:);
        b(1) = 0; b(end) = 0;
        u(:, n+1) = A \ b;
    end

    % Норма решения ||u(t)||
    u_norm = max(abs(u), [], 1);

    subplot(3,2, 2*test_id - 1);
    imagesc(t, x, u);
    xlabel('Время'); ylabel('x');
    title(['Численное решение, \omega = ', num2str(omega)]);
    colorbar;

    subplot(3,2, 2*test_id);
    plot(t, u_norm, 'b', 'LineWidth', 1.5);
    xlabel('Время'); ylabel('||u(t)||');
    title(['Рост амплитуды, \omega = ', num2str(omega)]);
end

