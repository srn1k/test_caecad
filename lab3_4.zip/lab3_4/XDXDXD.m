% Параметры задачи
L = 1;       % Длина струны
T = 5;       % Время моделирования
Nx = 5000;    % Число разбиений по пространству
Nt = 1000;    % Число разбиений по времени
a = 1;       % Скорость волны
omega = 2;   % Частота внешней силы

dx = L / Nx;
dt = T / Nt;
lambda = (a * dt / dx)^2;

% Инициализация сетки
x = linspace(0, L, Nx+1);
t = linspace(0, T, Nt+1);
u = zeros(Nx+1, Nt+1);

% Начальные условия
f = sin(pi * x);  % Пример распределения внешней силы
u(:,1) = sin(pi * x);  % Начальное смещение струны

% Коэффициенты прогонки
A = -lambda * ones(Nx-2, 1);
B = (2 + 2*lambda) * ones(Nx-1, 1);
C = -lambda * ones(Nx-2, 1);

% Прогонка (метод Томаса)
for n = 2:Nt
    % Формируем вектор правой части
    d = u(2:Nx, n) + dt^2 * f(2:Nx)' * sin(omega * t(n));

    % Метод прогонки (прямой ход)
    alpha = zeros(Nx-1, 1);
    beta = zeros(Nx-1, 1);

    % Первое значение alpha и beta
    alpha(1) = -C(1) / B(1);
    beta(1) = d(1) / B(1);

    % Основной цикл прогонки
    for i = 2:Nx-2
        denom = B(i) + A(i-1) * alpha(i-1);
        alpha(i) = -C(i) / denom;
        beta(i) = (d(i) - A(i-1) * beta(i-1)) / denom;
    end

    % Обратный ход прогонки
    u(Nx, n+1) = beta(end);
    for i = Nx-2:-1:1
        u(i+1, n+1) = alpha(i) * u(i+2, n+1) + beta(i);
    end
end

% Визуализация
[X, T] = meshgrid(x, t);
surf(X, T, u')
xlabel('x')
ylabel('t')
zlabel('u(x,t)')
title('Колебания струны')
shading interp

